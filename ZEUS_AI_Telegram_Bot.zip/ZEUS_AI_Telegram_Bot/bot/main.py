import asyncio
import logging
import os
from datetime import date
from typing import Optional

import aiosqlite
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv
from openai import AsyncOpenAI
import anthropic

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("zeus-ai")

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
DB_PATH = os.getenv("DATABASE_PATH", "zeus_ai.db")
FREE_DAILY_LIMIT = int(os.getenv("FREE_DAILY_LIMIT", "20"))
PREMIUM_DAILY_LIMIT = int(os.getenv("PREMIUM_DAILY_LIMIT", "300"))

MODELS = {
    "chatgpt": "ChatGPT",
    "gemini": "Gemini",
    "claude": "Claude",
    "deepseek": "DeepSeek",
    "perplexity": "Perplexity",
}
DEFAULT_MODEL = os.getenv("DEFAULT_MODEL", "chatgpt").lower()

dp = Dispatcher()
bot: Optional[Bot] = None

def model_keyboard():
    kb = InlineKeyboardBuilder()
    for key, label in MODELS.items():
        kb.button(text=label, callback_data=f"model:{key}")
    kb.adjust(2)
    return kb.as_markup()

def main_keyboard():
    kb = InlineKeyboardBuilder()
    kb.button(text="🤖 Choose AI", callback_data="choose_ai")
    kb.button(text="👤 My Account", callback_data="account")
    kb.button(text="ℹ️ Help", callback_data="help")
    kb.adjust(1, 2)
    return kb.as_markup()

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                model TEXT NOT NULL DEFAULT 'chatgpt',
                premium INTEGER NOT NULL DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS usage (
                user_id INTEGER NOT NULL,
                day TEXT NOT NULL,
                count INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (user_id, day)
            )
        """)
        await db.commit()

async def get_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users(user_id, model, premium) VALUES (?, ?, 0)",
            (user_id, DEFAULT_MODEL if DEFAULT_MODEL in MODELS else "chatgpt")
        )
        await db.commit()
        cur = await db.execute("SELECT model, premium FROM users WHERE user_id=?", (user_id,))
        return await cur.fetchone()

async def set_model(user_id: int, model: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET model=? WHERE user_id=?", (model, user_id))
        await db.commit()

async def set_premium(user_id: int, value: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users(user_id, model, premium) VALUES (?, 'chatgpt', 0)",
            (user_id,)
        )
        await db.execute("UPDATE users SET premium=? WHERE user_id=?", (value, user_id))
        await db.commit()

async def get_usage(user_id: int, premium: bool):
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO usage(user_id, day, count) VALUES (?, ?, 0)",
            (user_id, today)
        )
        cur = await db.execute(
            "SELECT count FROM usage WHERE user_id=? AND day=?", (user_id, today)
        )
        row = await cur.fetchone()
        await db.commit()
    return row[0] if row else 0, PREMIUM_DAILY_LIMIT if premium else FREE_DAILY_LIMIT

async def increment_usage(user_id: int):
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO usage(user_id, day, count) VALUES (?, ?, 0)",
            (user_id, today)
        )
        await db.execute(
            "UPDATE usage SET count=count+1 WHERE user_id=? AND day=?",
            (user_id, today)
        )
        await db.commit()

def env(name: str) -> str:
    return os.getenv(name, "").strip()

async def ask_ai(model: str, prompt: str) -> str:
    # OpenAI-compatible providers
    compatible = {
        "chatgpt": (env("OPENAI_API_KEY"), env("OPENAI_BASE_URL") or None, env("OPENAI_MODEL") or "gpt-4o-mini"),
        "gemini": (env("GEMINI_API_KEY"), "https://generativelanguage.googleapis.com/v1beta/openai/", env("GEMINI_MODEL") or "gemini-2.0-flash"),
        "deepseek": (env("DEEPSEEK_API_KEY"), "https://api.deepseek.com", env("DEEPSEEK_MODEL") or "deepseek-chat"),
        "perplexity": (env("PERPLEXITY_API_KEY"), "https://api.perplexity.ai", env("PERPLEXITY_MODEL") or "sonar"),
    }

    if model == "claude":
        key = env("ANTHROPIC_API_KEY")
        if not key:
            raise RuntimeError("Claude API key is not configured by the administrator.")
        client = anthropic.AsyncAnthropic(api_key=key)
        response = await client.messages.create(
            model=env("CLAUDE_MODEL") or "claude-3-5-haiku-latest",
            max_tokens=1200,
            messages=[{"role": "user", "content": prompt}],
        )
        return "\n".join(block.text for block in response.content if getattr(block, "type", "") == "text")

    if model not in compatible:
        raise RuntimeError("Unknown AI model.")
    key, base_url, model_name = compatible[model]
    if not key:
        raise RuntimeError(f"{MODELS[model]} API key is not configured by the administrator.")
    client = AsyncOpenAI(api_key=key, base_url=base_url)
    response = await client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
    )
    return response.choices[0].message.content or "No response received."

@dp.message(CommandStart())
async def start(message: Message):
    await get_user(message.from_user.id)
    await message.answer(
        "👑 <b>Welcome to ZEUS AI!</b>\n\n"
        "One bot, multiple AI assistants.\n"
        "Choose an AI model, then send your message.\n\n"
        "Use /menu to open the main menu.",
        reply_markup=main_keyboard(),
        parse_mode="HTML",
    )

@dp.message(Command("menu"))
async def menu(message: Message):
    await message.answer("👑 <b>ZEUS AI Menu</b>", reply_markup=main_keyboard(), parse_mode="HTML")

@dp.callback_query(F.data == "choose_ai")
async def choose_ai(callback: CallbackQuery):
    await callback.message.edit_text("Select your AI assistant:", reply_markup=model_keyboard())
    await callback.answer()

@dp.callback_query(F.data.startswith("model:"))
async def choose_model(callback: CallbackQuery):
    model = callback.data.split(":", 1)[1]
    if model not in MODELS:
        await callback.answer("Invalid model.", show_alert=True)
        return
    await set_model(callback.from_user.id, model)
    await callback.message.edit_text(
        f"✅ Selected: <b>{MODELS[model]}</b>\n\nNow send your question.",
        parse_mode="HTML",
        reply_markup=main_keyboard(),
    )
    await callback.answer("AI selected")

@dp.callback_query(F.data == "account")
async def account(callback: CallbackQuery):
    model, premium = await get_user(callback.from_user.id)
    used, limit = await get_usage(callback.from_user.id, bool(premium))
    status = "Premium" if premium else "Free"
    await callback.message.edit_text(
        f"👤 <b>Your ZEUS AI Account</b>\n"
        f"Plan: {status}\n"
        f"Selected AI: {MODELS.get(model, model)}\n"
        f"Today's usage: {used}/{limit}\n\n"
        "For plan upgrades, contact the bot administrator.",
        parse_mode="HTML",
        reply_markup=main_keyboard(),
    )
    await callback.answer()

@dp.callback_query(F.data == "help")
async def help_callback(callback: CallbackQuery):
    await callback.message.edit_text(
        "ℹ️ <b>How to use ZEUS AI</b>\n\n"
        "1. Tap Choose AI.\n"
        "2. Select ChatGPT, Gemini, Claude, DeepSeek or Perplexity.\n"
        "3. Send your question as a Telegram message.\n"
        "4. Use /menu to return.\n\n"
        "Free and Premium accounts have separate daily usage limits.",
        parse_mode="HTML",
        reply_markup=main_keyboard(),
    )
    await callback.answer()

@dp.message(Command("premium"))
async def premium_command(message: Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("Premium access is managed by the ZEUS AI administrator.")
        return
    parts = (message.text or "").split()
    if len(parts) != 3 or parts[2] not in {"on", "off"}:
        await message.answer("Usage: /premium USER_ID on  OR  /premium USER_ID off")
        return
    try:
        target = int(parts[1])
    except ValueError:
        await message.answer("USER_ID must be a number.")
        return
    await set_premium(target, 1 if parts[2] == "on" else 0)
    await message.answer(f"Premium {'enabled' if parts[2] == 'on' else 'disabled'} for {target}.")

@dp.message(Command("id"))
async def show_id(message: Message):
    await message.answer(f"Your Telegram user ID: <code>{message.from_user.id}</code>", parse_mode="HTML")

@dp.message(F.text)
async def chat(message: Message):
    user_id = message.from_user.id
    model, premium = await get_user(user_id)
    used, limit = await get_usage(user_id, bool(premium))
    if used >= limit:
        await message.answer(
            f"Daily limit reached ({limit} messages). "
            "Please try again tomorrow or contact the administrator about Premium access."
        )
        return

    status = await message.answer(f"⏳ Asking {MODELS.get(model, model)}...")
    try:
        answer = await ask_ai(model, message.text)
        await increment_usage(user_id)
        # Telegram message limit is 4096 characters.
        for i in range(0, len(answer), 4000):
            await message.answer(answer[i:i+4000])
        await status.delete()
    except Exception as exc:
        log.exception("AI request failed")
        safe_error = str(exc)[:500]
        await status.edit_text(f"⚠️ Could not get an AI response.\n{safe_error}")

async def main():
    global bot
    if not BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is missing. Add it to your environment variables.")
    await init_db()
    bot = Bot(BOT_TOKEN)
    log.info("Starting ZEUS AI Telegram bot...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
