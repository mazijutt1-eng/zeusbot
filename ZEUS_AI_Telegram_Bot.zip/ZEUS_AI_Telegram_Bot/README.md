# ZEUS AI Telegram Bot

A Python Telegram bot with a model selector for ChatGPT, Gemini, Claude, DeepSeek and Perplexity. Includes a Free/Premium flag, daily message limits, basic account screen and admin commands.

## 1. Create the Telegram bot
1. Open Telegram and message **@BotFather**.
2. Send `/newbot` and follow the steps.
3. Copy the bot token. Keep it private.

## 2. Get provider API keys
Add API keys for the providers you want to offer. Each provider bills API usage separately; a ChatGPT Plus subscription does not include OpenAI API credits. You can leave a provider key blank, but that model will show a configuration error when selected.

- OpenAI: https://platform.openai.com/api-keys
- Gemini: https://aistudio.google.com/app/apikey
- Anthropic: https://console.anthropic.com/
- DeepSeek: https://platform.deepseek.com/
- Perplexity: https://www.perplexity.ai/settings/api

Check each provider's current pricing, usage limits and model availability before enabling it.

## 3. Run locally for testing
Python 3.11+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env`, then fill in `TELEGRAM_BOT_TOKEN`, your `ADMIN_IDS`, and the API keys you have. Start the bot:

```bash
python -m bot.main
```

To find your Telegram numeric ID, start the bot and send `/id`.

## 4. Deploy online with Railway
1. Push this project to a **private GitHub repository**.
2. In Railway, create a new project and deploy from that repository.
3. Railway detects the Dockerfile automatically.
4. Add the variables from `.env.example` in Railway's Variables panel.
5. Deploy and check the logs for `Starting ZEUS AI Telegram bot...`.

**Important:** Attach a persistent volume and set `DATABASE_PATH` to a file on that volume (for example `/data/zeus_ai.db`) so user plans and daily usage survive redeploys. Use a paid always-on worker/service for reliable 24/7 operation; free hosting tiers may sleep or have limits.

## 5. Admin commands
- `/id` — show your Telegram user ID.
- `/premium USER_ID on` — grant Premium.
- `/premium USER_ID off` — revoke Premium.
- `/menu` — show the menu.

Put your own numeric Telegram ID in `ADMIN_IDS`. Do not share bot tokens or API keys in chat or commit `.env` to GitHub.

## Current scope and next steps
This is a working starter version for text chat. Premium is manually assigned by the admin; no payment gateway is connected. Voice, image generation, group moderation, persistent conversation memory, analytics dashboard and automated subscriptions can be added as separate modules. Review provider terms and applicable privacy rules before collecting user data or offering account/data services.
